package com.work.common.utils;

import java.util.List;

public class Page<T> {
	private int total;//总条数
	private int page;//当前页
	private int size;//当前页条数
    private List<T> rows;
    private List<T> rows_1;
    private List<T> rows_2;
    private List<T> rows_3;
    private List<T> rows_4;
    private List<T> rows_5;
    private List<T> rows_6;
    private List<T> rows_7;
    private List<T> rows_8;
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public List<T> getRows() {
		return rows;
	}
	public void setRows(List<T> rows) {
		this.rows = rows;
	}
	public List<T> getRows_1() {
		return rows_1;
	}
	public void setRows_1(List<T> rows_1) {
		this.rows_1 = rows_1;
	}
	public List<T> getRows_2() {
		return rows_2;
	}
	public void setRows_2(List<T> rows_2) {
		this.rows_2 = rows_2;
	}
	public List<T> getRows_3() {
		return rows_3;
	}
	public void setRows_3(List<T> rows_3) {
		this.rows_3 = rows_3;
	}
	public List<T> getRows_4() {
		return rows_4;
	}
	public void setRows_4(List<T> rows_4) {
		this.rows_4 = rows_4;
	}
	public List<T> getRows_5() {
		return rows_5;
	}
	public void setRows_5(List<T> rows_5) {
		this.rows_5 = rows_5;
	}
	public List<T> getRows_6() {
		return rows_6;
	}
	public void setRows_6(List<T> rows_6) {
		this.rows_6 = rows_6;
	}
	public List<T> getRows_7() {
		return rows_7;
	}
	public void setRows_7(List<T> rows_7) {
		this.rows_7 = rows_7;
	}
	public List<T> getRows_8() {
		return rows_8;
	}
	public void setRows_8(List<T> rows_8) {
		this.rows_8 = rows_8;
	}  	
	
}
